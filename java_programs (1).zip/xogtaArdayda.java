import java.util.Scanner;

public class xogtaArdayda {
    private static String magac1, magac2, magac3;
    private static double qiimeyn1, qiimeyn2, qiimeyn3;
    private static int Cadadka= 0;

    private static double wadarta = 0;
    private static double uguBadnaan = -1;
    private static double uguYaraan = 101;

    public static void main(String[] args) {
        Scanner galin = new Scanner(System.in);
        int doorasho;

        do {
            System.out.println("    Xogta Ardayda");
            System.out.println("1. Ku dar arday");
            System.out.println("2. Tus warbixin");
            System.out.println("3. Raadso arday");
            System.out.println("4. Bax");
            doorasho = galin.nextInt();

            if (doorasho == 1) darArday(galin);
            else if (doorasho == 2) warbixin();
            else if (doorasho == 3) raadsoArday(galin);
        } while (doorasho != 4);
    }

    private static void darArday(Scanner g) {
        if (Cadadka >= 3) {
            System.out.println("Arday dheeraad ah lama darikaro.");
            return;
        }

        System.out.print("Magaca ardayga: ");
        String magaca = g.next();

        System.out.print("Qiimeynta: ");
        double qiimeyn = g.nextDouble();

        Cadadka++;
        wadarta +=  qiimeyn;
        if ( qiimeyn > uguBadnaan) uguBadnaan =  qiimeyn;
        if ( qiimeyn < uguYaraan) uguYaraan =  qiimeyn;

        if (Cadadka == 1) { magac1 = magaca; qiimeyn1 = qiimeyn; }
        else if (Cadadka == 2) { magac2 = magaca;  qiimeyn2 =  qiimeyn; }
        else { magac3 = magaca;  qiimeyn3 =  qiimeyn; }

        System.out.println("Arday la daray: " + magaca);
    }

    private static void warbixin() {
        if (Cadadka == 0) {
            System.out.println("Arday lama hayo.");
            return;
        }

        double celcelis = Math.round((wadarta / Cadadka) * 100) / 100.0;

        System.out.println("Cadadka Ardayda: " + Cadadka);
        System.out.println("Celcelis: " + celcelis);
        System.out.println("Darajada ugu sarraysa: " + uguBadnaan);
        System.out.println("Darajada ugu hooseysa: " + uguYaraan);
    }

    private static void raadsoArday(Scanner g) {
        if (Cadadka == 0) {
            System.out.println("Arday lama heli karo.");
            return;
        }

        System.out.print("Gali magaca aad raadineyso: ");
        String raadso = g.next();

        if (raadso.equalsIgnoreCase(magac1))
            System.out.println("qiimeynta waa: " +  qiimeyn1);
        else if (raadso.equalsIgnoreCase(magac2))
            System.out.println("qiimeynta waa: " +  qiimeyn2);
        else if (raadso.equalsIgnoreCase(magac3))
            System.out.println("qiimeynta waa: " +  qiimeyn3);
        else
            System.out.println("Lama helin.");
    }
}
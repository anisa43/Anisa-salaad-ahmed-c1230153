import java.util.Scanner;

public class assign {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a number (3 or 4 digits): ");
        String number = input.nextLine();

        int len = number.length();

        boolean isPalindrome = false;

        if (len == 3) {
            if (number.charAt(0) == number.charAt(2)) {
                isPalindrome = true;
            }
        } else if (len == 4) {
            if (number.charAt(0) == number.charAt(3) && number.charAt(1) == number.charAt(2)) {
                isPalindrome = true;
            }
        } else {
            System.out.println("please enter only 3 or 4 digit number.");
            return;

        }

        if (isPalindrome) {
            System.out.println(number + " is a Palindrome.");
        } else {
            System.out.println(number + " is NOT a Palindrome.");
        }
    }
}
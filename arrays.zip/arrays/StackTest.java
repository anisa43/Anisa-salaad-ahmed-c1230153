public class StackTest {
    public static void main(String[] args) {
        GenericStack<String> myStack = new GenericStack<>();

        myStack.push("sihaam");
        myStack.push("aisha");
        myStack.push("senab");

        myStack.display();

        System.out.println("Top element: " + myStack.peek());
        System.out.println("Removed element: " + myStack.pop());
        myStack.display();

        System.out.println("Current size: " + myStack.size());
        System.out.println("Is stack empty? " + myStack.isEmpty());

    }

}

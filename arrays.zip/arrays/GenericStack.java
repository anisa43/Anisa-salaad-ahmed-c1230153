import java.util.Arrays;
import java.util.EmptyStackException;

public class GenericStack<T> {
    private static final int DEFAULT_SIZE = 2;
    private int count;
    private T[] items;

    // No-arg constructor
    GenericStack() {
        this(DEFAULT_SIZE);
    }

    // Parameterized constructor
    GenericStack(int initialCapacity) {
        count = 0;
        items = (T[]) (new Object[initialCapacity]);
    }

    // Size method
    public int size() {
        return count;
    }

    // Push method
    public void push(T element) {
        if (size() == items.length)
            expand();
        items[count] = element;
        count++;
    }

    // Pop method
    public T pop() {
        if (isEmpty())
            throw new EmptyStackException();
        else {
            T result = items[--count];
            items[count] = null;
            return result;
        }
    }

    // Peek method
    public T peek() {
        if (isEmpty())
            throw new EmptyStackException();
        else
            return items[count - 1];
    }

    // isEmpty method
    public boolean isEmpty() {
        return count == 0;
    }

    // Expand method
    private void expand() {
        items = Arrays.copyOf(items, items.length * 2);
    }

    // Display method
    public void display() {
        if (isEmpty())
            throw new EmptyStackException();
        else
            System.out.println("Elements of the stack:");
        for (int i = 0; i < count; i++)
            System.out.println(items[i] + " ");
        System.out.println();
    }
}

